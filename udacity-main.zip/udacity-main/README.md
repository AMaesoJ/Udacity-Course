# udacity
Udacity and Nutanix [Hybrid Cloud Engineer Nanodegree](https://www.udacity.com/course/hybrid-cloud-engineer-nanodegree--nd321) materials.
